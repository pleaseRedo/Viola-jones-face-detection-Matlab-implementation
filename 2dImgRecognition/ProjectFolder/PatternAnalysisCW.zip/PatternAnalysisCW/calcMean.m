function meanVec = calcMean(dataMatrix)
    vectorNum    = length(dataMatrix);
    meanVec = sum(dataMatrix)/vectorNum;
end
