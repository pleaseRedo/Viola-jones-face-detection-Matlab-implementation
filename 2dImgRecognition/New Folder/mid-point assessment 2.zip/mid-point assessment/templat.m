[pMiu pPi pSigma] = initEM(dataM,3);
clusters = getClusters('images/train',6);
gmmM = gmm(clusters,6);

unSupervisedOut = classifyGmm(gmmM,'images/train');