% mu = [0 0];
% model = models(1);
% modelMean = model.mean;
% transMean = transpose(modelMean)
% modelCovariance = model.cov;
% modelPrior = model.prior;
% Sigma = [.25 .3; .3 1];
% x1 = -1000:10:1000; x2 = -1000:10:1000;
% [X1,X2] = meshgrid(x1,x2);
% F = mvnpdf([X1(:) X2(:)],transMean,modelCovariance);
% F = reshape(F,length(x2),length(x1));
% surf(x1,x2,F);
% caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
% %axis([-3 3 -3 3 0 .4]);
% xlabel('x1'); ylabel('x2'); zlabel('Probability Density');
% hold on;
clear;
B = getDataMatrix('images/train','Alien',3);
%C = getDataMatrix('images/train','Face',2);
C = getDataMatrix('images/train','Star',3);
for i=1:size(B)
    %i
    
    %B(1,i)
    %scatter(B(1,1),i)
    scatter(B(i,1),B(i,2),[],[1,1,0],'filled')
    hold on;

end
for i=1:size(C)
    %i
    
    %B(1,i)
    %scatter(B(1,1),i)
    scatter(C(i,1),C(i,2),[],[1,0,0])
    hold on;

end
